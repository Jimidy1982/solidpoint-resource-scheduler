/**
 * Main application file for SolidPoint Resource Organiser
 */

// Global state
let app = {
    groups: [],
    data: {
        projects: [],
        settings: {
            viewMode: 'week',
            timelineStart: null
        }
    }
};

// Flag to track if app is still initializing
let isInitializing = true;

// Make app globally accessible
window.app = app;
window.renderTimeline = renderTimeline;
window.GroupManager = GroupManager;
window.updateUndoRedoButtons = updateUndoRedoButtons;
window.isInitializing = isInitializing;

// Initialize the application
function init() {
    loadData();
    initGroupManager();
    initUndoRedo();
    renderTimeline();
    
    // Set up event listeners
    document.addEventListener('mousemove', handleDrag);
    document.addEventListener('mouseup', endDrag);
    
    // Set initial view mode
    const viewModeSelect = document.getElementById('viewMode');
    if (viewModeSelect) {
        viewModeSelect.value = app.data.settings.viewMode || 'week';
        viewModeSelect.addEventListener('change', (e) => setViewMode(e.target.value));
    }
    
    // Set up button event listeners
    const prevBtn = document.getElementById('prevBtn');
    if (prevBtn) {
        prevBtn.addEventListener('click', () => navigateTimeline(-1));
    }
    
    const nextBtn = document.getElementById('nextBtn');
    if (nextBtn) {
        nextBtn.addEventListener('click', () => navigateTimeline(1));
    }
    
    const todayBtn = document.getElementById('todayBtn');
    if (todayBtn) {
        todayBtn.addEventListener('click', jumpToToday);
    }
    
    const addProjectBtn = document.getElementById('addProjectBtn');
    if (addProjectBtn) {
        addProjectBtn.addEventListener('click', showGlobalAddProject);
    }
    
    const exportBtn = document.getElementById('exportBtn');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportCSV);
    }
    
    const dataCleanupBtn = document.getElementById('dataCleanupBtn');
    if (dataCleanupBtn) {
        dataCleanupBtn.addEventListener('click', () => DataCleanup.show());
    }
    
    // Add undo/redo button listeners
    const undoBtn = document.getElementById('undoBtn');
    if (undoBtn) {
        undoBtn.addEventListener('click', performUndo);
    }
    
    const redoBtn = document.getElementById('redoBtn');
    if (redoBtn) {
        redoBtn.addEventListener('click', performRedo);
    }
    
    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        if (e.key === 'ArrowLeft') navigateTimeline(-1);
        if (e.key === 'ArrowRight') navigateTimeline(1);
        
        // Undo/Redo keyboard shortcuts
        if (e.ctrlKey || e.metaKey) {
            if (e.key === 'z' && !e.shiftKey) {
                e.preventDefault();
                performUndo();
            } else if ((e.key === 'y') || (e.key === 'z' && e.shiftKey)) {
                e.preventDefault();
                performRedo();
            }
        }
    });
    
    // Mark initialization as complete after a short delay
    setTimeout(() => {
        isInitializing = false;
        window.isInitializing = false;
        updateUndoRedoButtons();
    }, 100);
}

// Initialize group manager
function initGroupManager() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    
    // Remove the existing add group button since GroupManager will handle it
    const existingAddBtn = sidebar.querySelector('.add-btn');
    if (existingAddBtn) {
        existingAddBtn.remove();
    }
    
    GroupManager.init(sidebar, {
        onGroupsChange: (groups, operation) => {
            // No state saving for group operations - focus only on projects
            app.groups = groups;
            saveGroups();
            renderTimeline();
            // Don't update undo/redo buttons here - let applyState handle it
        }
    });
    
    // Set initial groups
    GroupManager.setGroups(app.groups);
}

// Initialize undo/redo functionality
function initUndoRedo() {
    UndoRedoService.init();
    // Clear any existing states to start fresh
    UndoRedoService.clear();
    // Validate stacks to ensure clean state
    UndoRedoService.validateStacks();
    updateUndoRedoButtons();
}

// Update undo/redo button states
function updateUndoRedoButtons() {
    const undoBtn = document.getElementById('undoBtn');
    const redoBtn = document.getElementById('redoBtn');
    
    const canUndo = UndoRedoService.canUndo();
    const canRedo = UndoRedoService.canRedo();
    
    if (undoBtn) {
        undoBtn.disabled = !canUndo;
        undoBtn.title = canUndo ? 'Undo (Ctrl+Z)' : 'Nothing to undo';
    }
    
    if (redoBtn) {
        redoBtn.disabled = !canRedo;
        redoBtn.title = canRedo ? 'Redo (Ctrl+Y)' : 'Nothing to redo';
    }
}

// Perform undo operation
function performUndo() {
    const state = UndoRedoService.undo();
    if (state) {
        applyState(state);
        showUndoRedoNotification('Undo: ' + UndoRedoService.getOperationDescription(state.operation));
    }
}

// Perform redo operation
function performRedo() {
    const state = UndoRedoService.redo();
    if (state) {
        applyState(state);
        showUndoRedoNotification('Redo: ' + UndoRedoService.getOperationDescription(state.operation));
    }
}

// Apply a saved state
function applyState(state) {
    // Set the undo/redo operation flag to prevent saving states during restoration
    UndoRedoService.isUndoRedoOperation = true;
    
    // Restore projects
    if (state.data.projects !== undefined) {
        app.data.projects = state.data.projects;
    }
    
    // Restore groups
    if (state.data.groups !== undefined) {
        app.groups = state.data.groups;
        GroupManager.setGroups(app.groups);
    }
    
    // Restore settings
    if (state.data.settings !== undefined) {
        app.data.settings = state.data.settings;
    }
    
    // Save to localStorage and re-render
    saveData();
    saveGroups();
    renderTimeline();
    
    // Update undo/redo buttons after state restoration
    updateUndoRedoButtons();
    
    // Reset the undo/redo operation flag after a short delay
    setTimeout(() => {
        UndoRedoService.isUndoRedoOperation = false;
    }, 100);
}

// Show undo/redo notification
function showUndoRedoNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'undo-redo-notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--sp-purple);
        color: white;
        padding: 12px 20px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 2 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 2000);
}

// Data management
function loadData() {
    // Load groups
    const savedGroups = localStorage.getItem('sp_groups');
    if (savedGroups) {
        app.groups = JSON.parse(savedGroups);
    } else {
        // Add default group if none exists
        app.groups = [
            {
                name: 'Development',
                resources: [
                    { name: 'Developer 1' },
                    { name: 'Developer 2' }
                ]
            }
        ];
        saveGroups();
    }
    
    // Load project data
    const savedData = localStorage.getItem('sp_resource_data');
    if (savedData) {
        app.data = JSON.parse(savedData);
    } else {
        // Set default settings
        app.data = {
            projects: [],
            settings: {
                viewMode: 'week',
                timelineStart: DateUtils.todayStr()
            }
        };
        saveData();
    }
}

function saveData() {
    localStorage.setItem('sp_resource_data', JSON.stringify(app.data));
}

function saveGroups() {
    localStorage.setItem('sp_groups', JSON.stringify(app.groups));
}

// Timeline rendering
function renderTimeline() {
    const timelineArea = document.getElementById('timelineArea');
    if (!timelineArea) return;
    
    // Initialize timeline if not already done
    if (!timelineArea.timeline) {
        timelineArea.timeline = true;
        Timeline.init(timelineArea, {
            groups: app.groups,
            projects: app.data.projects,
            onCellClick: addProjectAtCell,
            onProjectEdit: showProjectDetails,
            onProjectDuplicate: duplicateProject,
            onProjectDelete: deleteProject,
            onProjectUpdate: updateProject
        });
    }
    
    // Render the timeline
    Timeline.render({
        viewMode: app.data.settings.viewMode,
        timelineStart: app.data.settings.timelineStart,
        groups: app.groups,
        projects: app.data.projects
    });
}

// Group management - Now handled by GroupManager component
// The following functions are kept for backward compatibility but delegate to GroupManager

function addGroup() {
    GroupManager.addGroup();
}

function deleteGroup(idx) {
    GroupManager.deleteGroup(idx);
}

function addResource(group) {
    const groupIndex = app.groups.findIndex(g => g.name === group.name);
    if (groupIndex !== -1) {
        GroupManager.addResource(groupIndex);
    }
}

function deleteResource(group, idx) {
    const groupIndex = app.groups.findIndex(g => g.name === group.name);
    if (groupIndex !== -1) {
        GroupManager.deleteResource(groupIndex, idx);
    }
}

// Project actions
function addProjectAtCell(group, resource, date) {
    // Save state before operation (only if not an undo/redo operation and not initializing)
    if (!UndoRedoService.isUndoRedoOperation && !isInitializing) {
        UndoRedoService.saveState('add-project', {
            projects: [...app.data.projects],
            groups: [...app.groups],
            settings: { ...app.data.settings }
        });
    }
    
    const newProj = {
        id: generateId(),
        name: 'New Project',
        resourceId: resource.name,
        groupId: group.name,
        start: date,
        end: date,
        color: '#b39ddb',
        notes: ''
    };
    
    app.data.projects.push(newProj);
    saveData();
    renderTimeline();
    // Don't update undo/redo buttons here - let applyState handle it
    
    setTimeout(() => showProjectDetails(newProj), 100);
}

function updateProject(project) {
    // Save state before operation (only if not an undo/redo operation and not initializing)
    if (!UndoRedoService.isUndoRedoOperation && !isInitializing) {
        UndoRedoService.saveState('edit-project', {
            projects: [...app.data.projects],
            groups: [...app.groups],
            settings: { ...app.data.settings }
        });
    }
    
    const index = app.data.projects.findIndex(p => p.id === project.id);
    if (index !== -1) {
        app.data.projects[index] = project;
        saveData();
        renderTimeline();
        // Don't update undo/redo buttons here - let applyState handle it
    }
}

function duplicateProject(pid) {
    // Save state before operation (only if not an undo/redo operation and not initializing)
    if (!UndoRedoService.isUndoRedoOperation && !isInitializing) {
        UndoRedoService.saveState('duplicate-project', {
            projects: [...app.data.projects],
            groups: [...app.groups],
            settings: { ...app.data.settings }
        });
    }
    
    const p = app.data.projects.find(p => p.id === pid);
    if (!p) return;
    
    const copy = { ...p, id: generateId(), name: p.name + ' (Copy)' };
    app.data.projects.push(copy);
    saveData();
    renderTimeline();
    // Don't update undo/redo buttons here - let applyState handle it
}

function deleteProject(pid) {
    // Save state before operation (only if not an undo/redo operation and not initializing)
    if (!UndoRedoService.isUndoRedoOperation && !isInitializing) {
        UndoRedoService.saveState('delete-project', {
            projects: [...app.data.projects],
            groups: [...app.groups],
            settings: { ...app.data.settings }
        });
    }
    
    app.data.projects = app.data.projects.filter(p => p.id !== pid);
    saveData();
    renderTimeline();
    // Don't update undo/redo buttons here - let applyState handle it
}

// Project details
function showProjectDetails(project) {
    ProjectDetails.show(project, {
        onSave: (updatedProject) => {
            updateProject(updatedProject);
        },
        onDelete: (projectId) => {
            deleteProject(projectId);
        },
        onColorChange: (project) => {
            updateProject(project);
        }
    });
}

// Utility functions
function generateId() {
    return '_' + Math.random().toString(36).substr(2, 9);
}

// Drag and drop handling
function handleDrag(e) {
    // This will be handled by the Timeline component
}

function endDrag() {
    // This will be handled by the Timeline component
}

// Navigation functions
function navigateTimeline(direction) {
    const days = direction * (app.data.settings.viewMode === 'month' ? 30 :
                            app.data.settings.viewMode === '2week' ? 14 : 7);
    
    let start = new Date(app.data.settings.timelineStart || DateUtils.todayStr());
    start.setDate(start.getDate() + days);
    app.data.settings.timelineStart = start.toISOString().slice(0, 10);
    
    saveData();
    renderTimeline();
}

function jumpToToday() {
    app.data.settings.timelineStart = DateUtils.todayStr();
    saveData();
    renderTimeline();
}

function setViewMode(mode) {
    app.data.settings.viewMode = mode;
    saveData();
    renderTimeline();
}

// Export function
function exportCSV() {
    const rows = [['Group', 'Resource', 'Project', 'Start', 'End', 'Color', 'Notes']];
    
    app.data.projects.forEach(p => {
        const group = app.groups.find(g => g.name === p.groupId);
        rows.push([
            group ? group.name : '',
            p.resourceId,
            p.name,
            p.start,
            p.end,
            p.color || '',
            p.notes || ''
        ]);
    });
    
    const csv = rows.map(r => r.map(x => `"${x}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'solidpoint_resource_export.csv';
    a.click();
}

// Global add project - Fixed to match monolithic version
function showGlobalAddProject() {
    ProjectDetails.close();
    
    const closeArea = document.createElement('div');
    closeArea.className = 'close-area';
    closeArea.onclick = ProjectDetails.close;
    closeArea.tabIndex = 0;
    document.body.appendChild(closeArea);

    const groupOptions = app.groups.map((g, i) => `<option value="${i}">${g.name}</option>`).join('');
    const resourceOptions = app.groups.length > 0 && app.groups[0].resources.length > 0
        ? app.groups[0].resources.map((r, i) => `<option value="${i}">${r.name}</option>`).join('')
        : '';
    const today = DateUtils.todayStr();

    const projectDetails = document.createElement('div');
    projectDetails.className = 'project-details';
    projectDetails.innerHTML = `
        <h3>Add Project</h3>
        <label>Group:</label>
        <select id="globalAddGroup">${groupOptions}</select>
        <label>Resource:</label>
        <select id="globalAddResource">${resourceOptions}</select>
        <label>Date:</label>
        <input type="date" id="globalAddDate" value="${today}">
        <div class="buttons">
            <button class="cancel" onclick="ProjectDetails.close()">Cancel</button>
            <button class="save" onclick="addProjectFromGlobal()">Add</button>
        </div>
    `;
    document.body.appendChild(projectDetails);

    document.getElementById('globalAddGroup').onchange = function() {
        const gi = parseInt(this.value);
        const resSel = document.getElementById('globalAddResource');
        resSel.innerHTML = app.groups[gi].resources.map((r, i) => `<option value="${i}">${r.name}</option>`).join('');
    };
}

function addProjectFromGlobal() {
    const gi = parseInt(document.getElementById('globalAddGroup').value);
    const ri = parseInt(document.getElementById('globalAddResource').value);
    const date = document.getElementById('globalAddDate').value;
    if (isNaN(gi) || isNaN(ri) || !date) return;
    
    const group = app.groups[gi];
    const resource = group.resources[ri];
    addProjectAtCell(group, resource, date);
    ProjectDetails.close();
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init); 