/**
 * Data cleanup component for managing localStorage data and performance
 */

const DataCleanup = {
    /**
     * Show the data cleanup dialog
     */
    show() {
        this.close();
        
        const stats = StorageService.getStats();
        
        const closeArea = DomUtils.createElement('div', {
            className: 'close-area'
        });
        closeArea.onclick = () => this.close();
        document.body.appendChild(closeArea);

        const dialog = DomUtils.createElement('div', {
            className: 'project-details'
        });
        
        dialog.innerHTML = `
            <h3>Data Cleanup & Performance</h3>
            <div style="margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 4px; font-family: monospace; font-size: 14px;">
                Groups: ${stats.groups}<br>
                Resources: ${stats.resources}<br>
                Projects: ${stats.projects}<br>
                Storage Size: ${stats.storageSizeKB} KB<br>
                Old Projects (>6 months): ${stats.oldProjects}
            </div>
            <div style="margin-bottom: 15px;">
                <button id="exportAllBtn" style="width: 100%; margin-bottom: 8px; background: #4caf50; color: white;">📥 Export All Data</button>
                <button id="clearOldBtn" style="width: 100%; margin-bottom: 8px; background: #ff9800; color: white;">🗑️ Clear Old Projects (${stats.oldProjects})</button>
                <button id="clearAllBtn" style="width: 100%; background: #f44336; color: white;">🗑️ Clear All Data</button>
            </div>
            <div class="buttons">
                <button class="cancel" onclick="DataCleanup.close()">Close</button>
            </div>
        `;
        
        document.body.appendChild(dialog);
        
        // Add event listeners
        document.getElementById('exportAllBtn').onclick = () => this.exportAll();
        document.getElementById('clearOldBtn').onclick = () => this.clearOldProjects();
        document.getElementById('clearAllBtn').onclick = () => this.clearAllData();
        
        this.dialog = dialog;
        this.closeArea = closeArea;
    },

    /**
     * Close the data cleanup dialog
     */
    close() {
        if (this.dialog) {
            this.dialog.remove();
            this.dialog = null;
        }
        if (this.closeArea) {
            this.closeArea.remove();
            this.closeArea = null;
        }
    },

    /**
     * Export all data
     */
    exportAll() {
        const exportData = StorageService.exportAll();
        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `solidpoint-backup-${new Date().toISOString().slice(0,10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
        alert('Data exported successfully!');
    },

    /**
     * Clear old projects
     */
    clearOldProjects() {
        const cleared = StorageService.clearOldProjects();
        if (cleared === 0) {
            alert('No old projects found!');
            return;
        }
        
        if (confirm(`Delete ${cleared} old projects (ending before 6 months ago)?`)) {
            StorageService.clearOldProjects();
            alert(`Cleared ${cleared} old projects!`);
            this.close();
            // Refresh the app
            if (typeof window !== 'undefined' && window.app) {
                window.app.data.projects = StorageService.load('sp_resource_data', { projects: [] }).projects;
                window.renderTimeline();
            }
        }
    },

    /**
     * Clear all data
     */
    clearAllData() {
        if (confirm('Are you sure you want to delete ALL data? This cannot be undone!')) {
            StorageService.clearAppData();
            alert('All data cleared!');
            this.close();
            // Refresh the app
            if (typeof window !== 'undefined' && window.app) {
                window.app.groups = [];
                window.app.data = { projects: [], settings: { viewMode: 'week', timelineStart: null } };
                window.GroupManager.setGroups([]);
                window.renderTimeline();
            }
        }
    }
}; 