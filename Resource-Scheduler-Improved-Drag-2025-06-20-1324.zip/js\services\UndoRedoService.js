/**
 * Undo/Redo Service for managing project operation history
 */

const UndoRedoService = {
    undoStack: [],
    redoStack: [],
    maxStackSize: 10,
    isUndoRedoOperation: false,
    
    /**
     * Initialize the service
     */
    init() {
        this.undoStack = [];
        this.redoStack = [];
        this.isUndoRedoOperation = false;
    },

    /**
     * Save a state before an operation
     * @param {string} operation - Type of operation
     * @param {Object} data - Data to save
     */
    saveState(operation, data) {
        if (this.isUndoRedoOperation) {
            return;
        }

        // Only save if we have meaningful changes
        if (!data || !data.projects) {
            return;
        }

        // Check if this is a duplicate of the last state (more robust check)
        if (this.undoStack.length > 0) {
            const lastState = this.undoStack[this.undoStack.length - 1];
            const currentProjectsStr = JSON.stringify(data.projects);
            const lastProjectsStr = JSON.stringify(lastState.data.projects);
            
            if (lastState.operation === operation && currentProjectsStr === lastProjectsStr) {
                return;
            }
        }

        // Check if this operation happened very recently (within 1 second)
        const now = Date.now();
        if (this.undoStack.length > 0) {
            const lastState = this.undoStack[this.undoStack.length - 1];
            if (lastState.operation === operation && (now - lastState.timestamp) < 1000) {
                return;
            }
        }

        const state = {
            operation,
            data: JSON.parse(JSON.stringify(data)), // Deep copy
            timestamp: now
        };

        this.undoStack.push(state);
        
        // Clear redo stack when new operation is performed
        this.redoStack = [];
        
        // Keep only the last 10 operations
        if (this.undoStack.length > this.maxStackSize) {
            this.undoStack.shift();
        }
    },

    /**
     * Undo the last operation
     * @returns {Object|null} The previous state or null if no undo available
     */
    undo() {
        if (this.undoStack.length === 0) {
            return null;
        }

        const state = this.undoStack.pop();
        this.redoStack.push(state);
        
        this.isUndoRedoOperation = true;
        
        return state;
    },

    /**
     * Redo the last undone operation
     * @returns {Object|null} The next state or null if no redo available
     */
    redo() {
        if (this.redoStack.length === 0) {
            return null;
        }

        const state = this.redoStack.pop();
        this.undoStack.push(state);
        
        this.isUndoRedoOperation = true;
        
        return state;
    },

    /**
     * Check if undo is available
     * @returns {boolean}
     */
    canUndo() {
        return this.undoStack.length > 0;
    },

    /**
     * Check if redo is available
     * @returns {boolean}
     */
    canRedo() {
        return this.redoStack.length > 0;
    },

    /**
     * Clear all history
     */
    clear() {
        this.undoStack = [];
        this.redoStack = [];
    },

    /**
     * Get operation description for display
     * @param {string} operation - Operation type
     * @returns {string} Human readable description
     */
    getOperationDescription(operation) {
        const descriptions = {
            'add-project': 'Add Project',
            'edit-project': 'Edit Project',
            'delete-project': 'Delete Project',
            'duplicate-project': 'Duplicate Project',
            'add-group': 'Add Group',
            'edit-group': 'Edit Group',
            'delete-group': 'Delete Group',
            'add-resource': 'Add Resource',
            'edit-resource': 'Edit Resource',
            'delete-resource': 'Delete Resource',
            'bulk-edit': 'Bulk Edit',
            'bulk-delete': 'Bulk Delete'
        };
        return descriptions[operation] || operation;
    },

    /**
     * Debug function to log current state
     */
    debugState() {
        console.log('🔍 UndoRedoService Debug State:', {
            undoStackLength: this.undoStack.length,
            redoStackLength: this.redoStack.length,
            isUndoRedoOperation: this.isUndoRedoOperation,
            maxStackSize: this.maxStackSize,
            undoStack: this.undoStack.map(s => ({ operation: s.operation, timestamp: s.timestamp })),
            redoStack: this.redoStack.map(s => ({ operation: s.operation, timestamp: s.timestamp }))
        });
    },

    /**
     * Validate and clean up stacks
     */
    validateStacks() {
        // Clear any invalid states
        this.undoStack = this.undoStack.filter(state => 
            state && state.operation && state.data && state.data.projects
        );
        
        this.redoStack = this.redoStack.filter(state => 
            state && state.operation && state.data && state.data.projects
        );
    }
}; 