/**
 * Timeline component for rendering the timeline view
 */

const Timeline = {
    /**
     * Initialize the timeline
     * @param {HTMLElement} container - Container element
     * @param {Object} options - Timeline options
     */
    init(container, options = {}) {
        this.container = container;
        this.options = options;
        this.dragProject = null;
        this.dragStart = null;
        this.dragBarEl = null;
        this.dragOffset = null; // Track the offset from where user clicked on the bar
        this.resizeHandle = null;
        this.dates = [];
        this.startDate = null;
        this.endDate = null;
        this.groups = options.groups || [];
        this.dragOccurred = false; // Track if drag operation occurred

        // Set up event listeners
        document.addEventListener('mousemove', this.handleDrag.bind(this));
        document.addEventListener('mouseup', this.endDrag.bind(this));
    },

    /**
     * Calculate dates for the timeline
     * @param {string} viewMode - View mode (week, 2week, month)
     * @param {string} startDate - Start date
     * @returns {Object} Timeline dates info
     */
    calculateDates(viewMode, startDate) {
        const today = new Date();
        let start, end;
        
        if (!startDate) {
            start = new Date(today);
            start.setDate(start.getDate() - 7);
        } else {
            start = new Date(startDate);
        }
        
        end = new Date(start);
        
        switch (viewMode) {
            case 'week':
                end.setDate(start.getDate() + 6);
                break;
            case '2week':
                end.setDate(start.getDate() + 13);
                break;
            case 'month':
                end.setDate(start.getDate() + 29);
                break;
        }

        const dates = [];
        for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            dates.push(new Date(d));
        }

        return { start, end, dates };
    },

    /**
     * Render the timeline
     * @param {Object} data - Timeline data
     */
    render(data) {
        const { viewMode, timelineStart, groups, projects } = data;
        const { start, end, dates } = this.calculateDates(viewMode, timelineStart);
        
        this.dates = dates;
        this.startDate = start;
        this.endDate = end;
        this.groups = groups;
        this.projects = projects;

        // Clear container
        this.container.innerHTML = '';

        // Create table
        const table = document.createElement('table');
        table.className = 'timeline-table';

        // Create header
        const thead = this.createHeader(dates);
        table.appendChild(thead);

        // Create body
        const tbody = this.createBody(groups, dates, projects, start, end);
        table.appendChild(tbody);

        this.container.appendChild(table);

        // Render project bars
        this.renderProjects(table, dates, start, end);
    },

    /**
     * Create timeline header
     * @param {Array} dates - Array of dates
     * @returns {HTMLElement} Header element
     */
    createHeader(dates) {
        const thead = document.createElement('thead');
        const tr = document.createElement('tr');

        // Empty cell for resource names
        const th = document.createElement('th');
        tr.appendChild(th);

        // Date headers
        dates.forEach(date => {
            const th = document.createElement('th');
            th.textContent = DateUtils.formatDate(date);
            if (date.toDateString() === new Date().toDateString()) {
                th.className = 'today-col';
            }
            if (date.getDay() === 0 || date.getDay() === 6) {
                th.classList.add('weekend-col');
            }
            tr.appendChild(th);
        });

        thead.appendChild(tr);
        return thead;
    },

    /**
     * Create timeline body
     * @param {Array} groups - Array of groups
     * @param {Array} dates - Array of dates
     * @param {Array} projects - Array of projects
     * @param {Date} start - Start date
     * @param {Date} end - End date
     * @returns {HTMLElement} Body element
     */
    createBody(groups, dates, projects, start, end) {
        const tbody = document.createElement('tbody');
        let rowIndex = 0;

        groups.forEach((group, gi) => {
            // Group header row
            const groupHeaderTr = document.createElement('tr');
            groupHeaderTr.className = 'group-header-row';
            const th = document.createElement('th');
            th.colSpan = dates.length + 1;
            th.textContent = group.name;
            groupHeaderTr.appendChild(th);
            tbody.appendChild(groupHeaderTr);

            // Group divider row (except first group)
            if (gi > 0) {
                const dividerTr = document.createElement('tr');
                dividerTr.className = 'group-divider-row';
                for (let i = 0; i < dates.length + 1; i++) {
                    const td = document.createElement('td');
                    dividerTr.appendChild(td);
                }
                tbody.appendChild(dividerTr);
            }

            // Resource rows
            group.resources.forEach(resource => {
                // Calculate max stack for this resource (matching monolithic version)
                const projs = projects.filter(p =>
                    p.resourceId === resource.name &&
                    !(new Date(p.end) < start || new Date(p.start) > end)
                );
                projs.sort((a, b) => new Date(a.start) - new Date(b.start));
                const stacks = [];
                projs.forEach(proj => {
                    let placed = false;
                    for (let s = 0; s < stacks.length; s++) {
                        if (!this.doProjectsOverlap(proj, stacks[s][stacks[s].length - 1])) {
                            stacks[s].push(proj);
                            placed = true;
                            break;
                        }
                    }
                    if (!placed) stacks.push([proj]);
                });
                const maxStack = Math.max(1, stacks.length);

                const tr = document.createElement('tr');
                tr.style.height = (28 * maxStack) + "px";
                
                // Resource name cell
                const tdName = document.createElement('td');
                tdName.textContent = resource.name;
                tdName.style.fontWeight = '600';
                tdName.style.background = '#f8f6fc';
                tdName.style.position = 'relative';
                tr.appendChild(tdName);

                // Date cells
                dates.forEach(date => {
                    const td = document.createElement('td');
                    td.dataset.date = date.toISOString().slice(0, 10);
                    td.dataset.resource = resource.name;

                    if (date.toDateString() === new Date().toDateString()) {
                        td.classList.add('today-col');
                    }
                    if (date.getDay() === 0 || date.getDay() === 6) {
                        td.classList.add('weekend-col');
                    }

                    td.onclick = e => {
                        if (e.target === td) {
                            this.options.onCellClick?.(group, resource, date.toISOString().slice(0, 10));
                        }
                    };

                    tr.appendChild(td);
                });

                tbody.appendChild(tr);
                rowIndex++;
            });

            // Group padding row
            const padTr = document.createElement('tr');
            padTr.className = 'group-padding-row';
            for (let i = 0; i < dates.length + 1; i++) {
                const td = document.createElement('td');
                padTr.appendChild(td);
            }
            tbody.appendChild(padTr);
        });

        return tbody;
    },

    /**
     * Calculate project stacks to avoid overlaps
     * @param {Array} projects - Array of projects
     * @returns {Array} Array of project stacks
     */
    calculateProjectStacks(projects) {
        const sortedProjects = [...projects].sort((a, b) => new Date(a.start) - new Date(b.start));
        const stacks = [];
        
        sortedProjects.forEach(project => {
            let placed = false;
            for (let stack of stacks) {
                if (!this.doProjectsOverlap(project, stack[stack.length - 1])) {
                    stack.push(project);
                    placed = true;
                    break;
                }
            }
            if (!placed) {
                stacks.push([project]);
            }
        });
        return stacks;
    },

    /**
     * Check if two projects overlap
     * @param {Object} a - First project
     * @param {Object} b - Second project
     * @returns {boolean} True if projects overlap
     */
    doProjectsOverlap(a, b) {
        return !(new Date(a.end) < new Date(b.start) || new Date(a.start) > new Date(b.end));
    },

    /**
     * Render project bars
     * @param {HTMLElement} table - Timeline table
     * @param {Array} dates - Array of dates
     * @param {Date} start - Start date
     * @param {Date} end - End date
     */
    renderProjects(table, dates, start, end) {
        // Remove old bars
        const oldBars = this.container.querySelectorAll('.project-bar');
        oldBars.forEach(b => b.remove());
        
        const trs = table.querySelectorAll('tbody tr:not(.group-divider-row):not(.group-header-row):not(.group-padding-row)');
        let rowY = 0;
        
        this.groups.forEach(group => {
            group.resources.forEach(resource => {
                const projs = this.projects.filter(p =>
                    p.resourceId === resource.name &&
                    !(new Date(p.end) < start || new Date(p.start) > end)
                );
                projs.sort((a, b) => new Date(a.start) - new Date(b.start));
                
                const stacks = [];
                projs.forEach(proj => {
                    let placed = false;
                    for (let s = 0; s < stacks.length; s++) {
                        if (!this.doProjectsOverlap(proj, stacks[s][stacks[s].length - 1])) {
                            stacks[s].push(proj);
                            placed = true;
                            break;
                        }
                    }
                    if (!placed) stacks.push([proj]);
                });
                
                stacks.forEach((stack, si) => {
                    stack.forEach(proj => {
                        const bar = this.createProjectBar(proj, {
                            row: trs[rowY],
                            stackIndex: si
                        });
                        this.container.appendChild(bar);
                    });
                });
                rowY++;
            });
        });
    },

    /**
     * Create a project bar element
     * @param {Object} project - Project object
     * @param {Object} options - Options for positioning
     * @returns {HTMLElement} Project bar element
     */
    createProjectBar(project, options) {
        const bar = document.createElement('div');
        bar.className = 'project-bar';
        bar.style.background = project.color || 'var(--sp-project)';
        
        // Calculate visible start/end for this view
        const projStartIdx = Math.max(0, this.dates.findIndex(d => d.toISOString().slice(0, 10) >= project.start));
        let projEndIdx = Math.min(this.dates.length - 1, this.dates.findIndex(d => d.toISOString().slice(0, 10) > project.end) - 1);
        if (projEndIdx < 0) projEndIdx = this.dates.length - 1;
        
        const startIdx = Math.max(0, projStartIdx);
        const endIdx = Math.max(startIdx, projEndIdx);
        
        const tr = options.row;
        const cell = tr.children[startIdx + 1];
        const cell2 = tr.children[endIdx + 1];
        
        if (!cell || !cell2) return bar; // Safety check
        
        const left = cell.offsetLeft;
        const width = (cell2.offsetLeft - cell.offsetLeft) + cell2.offsetWidth - 2;
        
        bar.style.left = left + 'px';
        bar.style.width = width + 'px';
        bar.style.top = (tr.offsetTop + 3 + options.stackIndex * 26) + 'px';
        
        // Color dot
        const colorDot = document.createElement('span');
        colorDot.className = 'color-dot';
        colorDot.style.background = project.color || 'var(--sp-project)';
        colorDot.title = "Edit project details";
        colorDot.tabIndex = 0;
        colorDot.setAttribute('aria-label', 'Edit project details');
        colorDot.onclick = e => { 
            e.stopPropagation(); 
            this.options.onProjectEdit?.(project); 
        };
        colorDot.onkeydown = e => { 
            if (e.key === "Enter" || e.key === " ") { 
                this.options.onProjectEdit?.(project); 
            } 
        };
        bar.appendChild(colorDot);
        
        // Name (static)
        const nameSpan = document.createElement('span');
        nameSpan.className = 'project-name';
        nameSpan.textContent = project.name;
        nameSpan.title = project.name;
        bar.appendChild(nameSpan);
        
        // Actions
        const barActions = document.createElement('span');
        barActions.className = 'bar-actions';
        barActions.innerHTML = `
            <button title="Duplicate" aria-label="Duplicate project">&#128209;</button>
            <button title="Delete" aria-label="Delete project">&#10006;</button>
        `;
        
        // Fix the onclick handlers to use the proper context
        const duplicateBtn = barActions.querySelector('button[title="Duplicate"]');
        const deleteBtn = barActions.querySelector('button[title="Delete"]');
        
        duplicateBtn.onclick = e => {
            e.stopPropagation();
            this.options.onProjectDuplicate?.(project.id);
        };
        
        deleteBtn.onclick = e => {
            e.stopPropagation();
            this.options.onProjectDelete?.(project.id);
        };
        
        bar.appendChild(barActions);
        
        // Drag/resize
        bar.onmousedown = e => {
            this.dragProject = project;
            this.dragStart = { x: e.clientX, y: e.clientY };
            this.dragBarEl = bar;
            
            // Calculate the offset from where the user clicked relative to the bar's left edge
            const barRect = bar.getBoundingClientRect();
            this.dragOffset = e.clientX - barRect.left;
            
            bar.classList.add('selected');
            document.body.style.cursor = "grabbing";
            e.preventDefault();
        };
        
        // Resize handles
        const leftHandle = document.createElement('div');
        leftHandle.className = 'resize-handle left';
        leftHandle.title = "Resize project start";
        leftHandle.onmousedown = e => {
            this.resizeHandle = { proj: project, side: 'left' };
            e.stopPropagation();
        };
        
        const rightHandle = document.createElement('div');
        rightHandle.className = 'resize-handle right';
        rightHandle.title = "Resize project end";
        rightHandle.onmousedown = e => {
            this.resizeHandle = { proj: project, side: 'right' };
            e.stopPropagation();
        };
        
        bar.appendChild(leftHandle);
        bar.appendChild(rightHandle);
        
        return bar;
    },

    /**
     * Handle mouse drag events
     * @param {MouseEvent} e - Mouse event
     */
    handleDrag(e) {
        // --- DRAGGING ---
        if (this.dragProject && this.dragBarEl) {
            const table = document.querySelector('.timeline-table');
            const trs = table.querySelectorAll('tbody tr:not(.group-divider-row):not(.group-header-row):not(.group-padding-row)');
            let foundRow = null, foundCellIdx = null, foundRowIdx = null;
            
            // Calculate the target position considering the drag offset
            const targetX = e.clientX - this.dragOffset;
            
            for (let rowIdx = 0; rowIdx < trs.length; rowIdx++) {
                const tr = trs[rowIdx];
                const tds = Array.from(tr.children).slice(1);
                for (let i = 0; i < tds.length; i++) {
                    const rect = tds[i].getBoundingClientRect();
                    if (
                        targetX >= rect.left && targetX < rect.right &&
                        e.clientY >= rect.top && e.clientY < rect.bottom
                    ) {
                        foundRow = tr;
                        foundCellIdx = i;
                        foundRowIdx = rowIdx;
                        break;
                    }
                }
                if (foundRow) break;
            }
            
            if (foundRow && foundCellIdx !== null) {
                // Snap to this row and date
                const resourceName = foundRow.children[0].childNodes[0].nodeValue.trim();
                const duration = DateUtils.daysBetween(this.dragProject.start, this.dragProject.end);
                const newStartDate = this.dates[foundCellIdx].toISOString().slice(0, 10);
                const newEndDate = DateUtils.addDays(newStartDate, duration);
                
                this.dragProject.resourceId = resourceName;
                this.dragProject.start = newStartDate;
                this.dragProject.end = newEndDate;
                
                this.dragOccurred = true; // Mark that drag occurred
                
                // Update the project and trigger re-render (but don't save state during drag)
                this.options.onProjectUpdate?.(this.dragProject);
            }
        }
        
        // --- RESIZING ---
        if (this.resizeHandle) {
            const table = document.querySelector('.timeline-table');
            const cells = table.querySelectorAll('tbody tr:not(.group-divider-row):not(.group-header-row):not(.group-padding-row)');
            let rowIndex = -1, projRow = null;
            
            this.groups.forEach((group) => {
                group.resources.forEach((resource) => {
                    rowIndex++;
                    if (this.resizeHandle.proj.resourceId === resource.name) {
                        projRow = cells[rowIndex];
                    }
                });
            });
            
            if (!projRow) return;
            
            const tds = Array.from(projRow.children).slice(1);
            for (let i = 0; i < tds.length; i++) {
                const rect = tds[i].getBoundingClientRect();
                if (e.clientX >= rect.left && e.clientX < rect.right) {
                    const date = this.dates[i].toISOString().slice(0, 10);
                    if (this.resizeHandle.side === 'left') {
                        if (new Date(date) <= new Date(this.resizeHandle.proj.end)) {
                            this.resizeHandle.proj.start = date;
                        }
                    } else {
                        if (new Date(date) >= new Date(this.resizeHandle.proj.start)) {
                            this.resizeHandle.proj.end = date;
                        }
                    }
                    
                    this.dragOccurred = true; // Mark that resize occurred
                    
                    this.options.onProjectUpdate?.(this.resizeHandle.proj);
                    break;
                }
            }
        }
    },

    /**
     * End drag operation
     */
    endDrag() {
        if (this.dragProject || this.resizeHandle) {
            // Save state when drag/resize operation ends
            if (this.dragOccurred && window.UndoRedoService && !window.UndoRedoService.isUndoRedoOperation && !window.isInitializing) {
                const currentData = {
                    projects: window.app.data.projects || [],
                    groups: window.app.groups || [],
                    settings: window.app.data.settings || {}
                };
                
                console.log('💾 Saving drag/resize state');
                window.UndoRedoService.saveState('edit-project', currentData);
                
                // Don't update undo/redo buttons here - let applyState handle it
            }
            
            this.dragOccurred = false; // Reset flag
        }
        
        if (this.dragProject) {
            this.dragProject = null;
            this.dragStart = null;
            this.dragBarEl = null;
            this.dragOffset = null; // Reset the drag offset
            const bars = document.querySelectorAll('.project-bar');
            bars.forEach(bar => bar.classList.remove('selected'));
            document.body.style.cursor = "";
        }
        if (this.resizeHandle) {
            this.resizeHandle = null;
        }
    }
}; 